#include <string>
#include <iostream>

#include "GraduateStudent.h"

using std::string;
using std::cout;
using std::endl;

bool GraduateStudent::has_scholarship() const {
    return scholarship;
}
